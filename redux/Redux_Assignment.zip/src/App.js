import './App.css';
import Profile from './Profile';
import Login from './Login';


function App() {
  return (
    <div className="App">
       <Profile/>
       <Login/>
    </div>
  );
}

export default App;
